package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MubtakirApp
import com.example.ui.MubtakirViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val viewModel: MubtakirViewModel = viewModel()
      val isDarkModeOpt by viewModel.isDarkMode.collectAsState()
      val systemInDark = androidx.compose.foundation.isSystemInDarkTheme()
      val useDarkTheme = isDarkModeOpt ?: systemInDark

      MyApplicationTheme(darkTheme = useDarkTheme) {
        MubtakirApp(viewModel = viewModel)
      }
    }
  }
}
